Elasticsearch Capstone Assignment 4.2
Created by Jerwin Keith D. Dela Cruz
Enjoy!